document.addEventListener("DOMContentLoaded", () => {
    const burgerToggle = document.getElementById("burger-toggle");
    const navLinks = document.querySelector(".nav-links");

    burgerToggle.addEventListener("click", () => {
        navLinks.classList.toggle("show");
    });

    // Smooth scrolling
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener("click", function (e) {
            e.preventDefault();
            document.querySelector(this.getAttribute("href")).scrollIntoView({
                behavior: "smooth"
            });
        });
    });
});